# Operation Setting Sun

## Constitutional Programme

**Purpose:** Recover, refine, register, and migrate all Meridian legacy work into the Meridian Founders Repository.

## First Principle

Legacy work shall be recovered before it is refined.

## Phases

1. Constitutional Census
2. Recovery of artefacts
3. Classification and dependency mapping
4. Editorial refinement to Meridian Press standards
5. Registration
6. Repository migration
