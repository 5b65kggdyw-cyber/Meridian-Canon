# MER-001 — Master Knowledge Register

## Placeholder Recovery Record

**Status:** Draft / recovery pending

The Master Knowledge Register is the authoritative constitutional index of every Meridian Knowledge Object.

Full publication text pending repository migration and editorial review.
