# Meridian Founders Repository

**Version:** 0.1  
**Status:** Foundational repository skeleton  
**Purpose:** Permanent constitutional memory of Meridian.

This repository is the authoritative home for Meridian constitutional publications, knowledge objects, principles, registers, legacy recovery work, and implementation architecture.

## Constitutional Rule

No significant Meridian architectural work is considered complete until it exists in this repository.

## Initial Structure

- `00 Constitution/` — highest governing constitutional publications.
- `01 Constitutional Census/` — recovery records, constitutional facts, dependency matrix, and backlog.
- `02 Knowledge Objects/` — Meridian Knowledge Objects and related records.
- `03 Constitutional Principles/` — Meridian Constitutional Principles.
- `04 Registers/` — Master Knowledge Register, Master Architectural Register, and future registers.
- `05 Legacy Recovery/` — Operation Setting Sun and LEG recovery programme.
- `06 Implementations/` — Meridian App, Ashlar, Cursor, and future systems.

## Operating Principle

The repository remembers. Ashlar reasons from the repository.
