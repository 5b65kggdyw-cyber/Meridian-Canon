# MER-100 — Constitution of Meridian

## Placeholder Recovery Record

**Status:** Recovered — full publication text pending repository migration.

**Constitutional Role:** Establishes Meridian's constitutional identity, authority, and governance framework.

**Governed By:** MER-101 — The Meridian Way

**Migration Note:** Full text to be recovered and committed through Operation Setting Sun.
