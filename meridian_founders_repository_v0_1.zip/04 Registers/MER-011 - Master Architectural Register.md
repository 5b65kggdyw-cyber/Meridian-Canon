# MER-011 — Master Architectural Register

## Initial Repository Entry

This register tracks architectural publications and their editorial completion.

## Registered Publications

| ID | Title | Canon Status | Repository Status |
|---|---|---|---|
| MER-000 | Meridian Knowledge Object | Canon Approved | Awaiting migration |
| MER-005 | Constitution of the Meridian Founders Repository | Draft for Editorial Review | Committed |
