# Meridian Constitutional Census

**Status:** Active recovery record  
**Repository Version:** 0.1

## Purpose

The Constitutional Census identifies, verifies, classifies, and governs every constitutional artefact ever created within the Meridian project before full repository migration begins.

## Core Rules

- Recovery Before Refinement
- Evidence Before Assertion
- Recovery by Precedence
- Canon Before Memory
- Constitutional Persistence

## Current Recovery Domains

1. Meridian Philosophy Domain
2. Constitutional Identity Domain
3. Ashlar Constitutional Behaviour Domain
4. Knowledge Architecture Domain
5. Meridian Press Domain
6. Product Architecture Domain
7. Repository and Legacy Recovery Domain
