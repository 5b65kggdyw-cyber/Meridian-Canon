# MER-101 — The Meridian Way

## Placeholder Recovery Record

**Status:** Recovered — full publication text pending repository migration.

**Constitutional Role:** Highest governing philosophical document within the Meridian architecture.

**Recovered Pillars:**

1. Human First
2. Philosophy Before Features
3. Understanding Before Guidance
4. Engineering with Intention
5. Quiet Excellence
6. Capability in Service of Wisdom
7. Build for Decades

**Migration Note:** Full text to be recovered and committed through Operation Setting Sun.
