# PCR-001 — MER-101 The Meridian Way

**Recovery Status:** Recovered  
**Knowledge State:** Active  
**Editorial State:** Recovery complete; Canon verification pending through Census

## Constitutional Role

MER-101 establishes the philosophy and enduring ethos of Meridian.

Where the Constitution defines rules, The Meridian Way defines purpose.

## Recovered Pillars

1. Human First
2. Philosophy Before Features
3. Understanding Before Guidance
4. Engineering with Intention
5. Quiet Excellence
6. Capability in Service of Wisdom
7. Build for Decades

## Governs

- MER-100 — Constitution of Meridian
- Meridian Press
- Ashlar
- Knowledge Architecture
- Product Architecture
- Repository Architecture
- Operation Setting Sun
