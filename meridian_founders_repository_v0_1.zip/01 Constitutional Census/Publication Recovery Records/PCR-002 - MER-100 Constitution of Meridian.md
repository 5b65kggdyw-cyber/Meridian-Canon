# PCR-002 — MER-100 Constitution of Meridian

**Recovery Status:** Recovered  
**Knowledge State:** Active  
**Editorial State:** Recovery complete; Canon verification pending through Census

## Constitutional Role

MER-100 establishes Meridian's constitutional identity, authority, and governance framework.

## Governed By

- MER-101 — The Meridian Way

## Governs

- Meridian Press Governance
- Ashlar Constitutional Behaviour
- Knowledge Governance
- Product Governance
- Repository Governance
- Constitutional Amendment Procedures
